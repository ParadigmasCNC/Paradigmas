# INECO_SWM V2

This task is a working memory test using words as stimulus.

- Log files has 2 variables: log_practice and log_test. The log colomms are:

#of trial  |  Fix Onset  |  Stim Onset | Blank Onset | Test Onset | RT | Answer | Accuracy

- Anser can be: 1 for NO and 2 for YES, 0 is answer timeout
Accuracy can be: 1 for INCORRECT and 2 for CORRECT, 0 is answer timeout

- You can repeat Practice task pressing 'r' in Test Task introduction screen

- You can quit in any time pressing 'q' in blank or response screen, or in practice intro screen 